<?php
session_start();
include("../db_conn.php");
if(empty($_SESSION['username']))
{
    header("Location: ../signup.php");
    die("Redirecting to Login");
}
$user =$_SESSION['username'];
$pname=$_SESSION['pname'];
$price=$_SESSION['price'];
$email=$_SESSION['email'];
$state=$_POST['state'];
$addr=$_POST['addr'];
$pin=$_POST['pin'];
$city=$_POST['city'];
if(isset($_POST['submit']))
{
    $sql1 = "INSERT INTO product (pname,price,address,city,state,pin,customer,email) VALUES ('$pname', $price,'$addr','$city','$state',$pin,'$user','$email')";
    $result1 = mysqli_query($conn,$sql1);
    $msg="Your order has been placed!<br><br>Go to the home page to shop more!";
    $sql2= "select pname,price from product where customer='$user'";
    $result2= mysqli_query($conn,$sql2);
}
else
  $msg="Login to place your order!";
?>
<!DOCTYPE html>
<head>
<title>Floral Expressions</title>
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" type="text/css" href="../style.css">
</head>
<div class="logo" >
		<img src="../images/logo.jpg" alt="LOGO" width="400px;" height="80px" />
<ul>
	<li><?php if(isset($_SESSION['username'])&& $_SESSION['username']=='admin') echo"<a href='reports.php'>Reports</a>";
  else echo"<a href='aboutus.php'>About Us</a>";?></li>
	<li><?php if(isset($_SESSION['username'])) echo"<li><a href='logout.php'>Logout</a>"; ?></li>
  <li class="dropdown">
    <a href="javascript:void(0)" class="dropbtn">Shop</a>
    <div class="dropdown-content">
      <a href="../flower_bunch.php">Flower Bunches</a>
      <li><a href="../home.php">Home</a></li>
      <li><?php if(isset($_SESSION['username'])) echo "<a href='mycart.php'>My Cart</a>"; ?></li>
      <li><?php if(empty($_SESSION['username'])) {echo"<a href='../signup.php'>Sign up & Login</a>";}
      else {echo"<p style='color: teal;font-size: 20px;margin-right:110px;'>Welcome !<br>".$_SESSION['username'];} ?></li>
    </div>
  </li>
</ul>
</div>
</div>
<div>
	<center><h2 style="color: red;"><?php echo $msg ?></h2>
<h2><?php $sum=0; echo "Your cart details are as follows:"; ?></h2>
 <div style="text-align: left;margin-left: 30%;border-width: 2px;border-style: solid;margin-right: 30%"><h3 style="margin-left: 40px;"><?php $i=1; while ($row = mysqli_fetch_array($result2)){
                $pname = $row['pname'];
                $price = $row['price'];
                echo $i.".     ".$pname."-       Rs.".$price."<br>";
                $i=$i+1;
                $sum=$sum+$price; }
                 ?></h3>
<h3 style="color: red;"><?php echo"<hr>Total Bill: Rs.".$sum; ?></h3>
</div>
</div>
</body>
</html>